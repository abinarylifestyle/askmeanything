
  # Anonymous Message Board

  This is a code bundle for Anonymous Message Board. The original project is available at https://www.figma.com/design/RySJKZNKG8srCDEIZ5iT7S/Anonymous-Message-Board.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  