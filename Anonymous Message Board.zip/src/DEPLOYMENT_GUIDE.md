# 🚀 部署指南 - Ask Me Anything

## 📋 部署前准备（必须完成！）

### ✅ 第1步：设置 Supabase 数据库

**如果还没做，必须先完成这一步！**

1. 访问 [Supabase Dashboard](https://app.supabase.com)
2. 选择你的项目：`hzzvmykbodtbtphowybn`
3. 点击左侧 **SQL Editor**
4. 点击 **New Query**
5. 复制 `SETUP_DATABASE.sql` 文件的**全部内容**
6. 粘贴到编辑器中
7. 点击 **Run** 执行
8. 看到 "✅ 数据库设置完成！" 表示成功

---

## 🎯 方案一：部署到 Vercel（推荐 - 最简单）

### 为什么选择 Vercel？
- ✅ 全球 CDN 加速
- ✅ 自动 HTTPS
- ✅ 推送代码自动部署
- ✅ 免费额度足够使用

### 部署步骤

#### A. 从 Figma 导出代码

1. 在 Figma Make 中，点击右上角的 **导出** 或 **下载代码**
2. 解压下载的 ZIP 文件到本地文件夹
3. 打开终端/命令行，进入该文件夹：
   ```bash
   cd /path/to/your/project
   ```

#### B. 初始化 Git 仓库

```bash
# 初始化 Git
git init

# 添加所有文件
git add .

# 提交
git commit -m "Initial commit: Ask Me Anything app"
```

#### C. 推送到 GitHub

1. 访问 https://github.com/new
2. 创建新仓库（例如：`ask-me-anything`）
3. **不要**勾选任何初始化选项（README、.gitignore等）
4. 创建后，复制显示的命令：

```bash
# 添加远程仓库
git remote add origin https://github.com/你的用户名/ask-me-anything.git

# 推送代码
git branch -M main
git push -u origin main
```

#### D. 部署到 Vercel

1. 访问 https://vercel.com
2. 点击 **Sign Up** 注册（可以用 GitHub 账号登录）
3. 点击 **Add New** → **Project**
4. 选择刚才创建的 GitHub 仓库
5. 配置项目：
   - **Framework Preset**: Vite
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
   - **Install Command**: `npm install`
6. 点击 **Deploy**
7. 等待 2-3 分钟... ☕
8. 🎉 **完成！**点击预览链接查看你的应用！

#### E. 获取你的网址

部署成功后，Vercel 会给你一个网址，例如：
```
https://ask-me-anything-abc123.vercel.app
```

你也可以：
- 点击 **Settings** → **Domains** 添加自定义域名
- 每次推送代码到 GitHub，Vercel 会自动重新部署

---

## 🎯 方案二：部署到 Netlify

### 部署步骤

1. 访问 https://app.netlify.com
2. 点击 **Sign Up**（可以用 GitHub 登录）
3. 点击 **Add new site** → **Import an existing project**
4. 选择 **GitHub** 并授权
5. 选择你的仓库
6. 配置构建设置：
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
7. 点击 **Deploy site**
8. 等待部署完成
9. 🎉 完成！

---

## 🎯 方案三：部署到其他平台

### Cloudflare Pages

```bash
npm install -g wrangler
wrangler pages publish dist
```

### Railway

1. 访问 https://railway.app
2. 连接 GitHub 仓库
3. 自动检测并部署

---

## ✅ 部署后验证

### 1. 检查数据库连接

访问你的网站，应该看到：
```
✅ 已连接到 Supabase 真实数据库 - 所有数据将永久保存
```

如果看到这个，说明连接成功！

### 2. 测试功能

- [ ] 创建新话题
- [ ] 刷新页面，话题依然存在
- [ ] 发送留言
- [ ] 点击表情反应
- [ ] 在 Supabase Dashboard 的 Table Editor 中查看数据

### 3. 在 Supabase 中验证数据

1. 打开 Supabase Dashboard
2. 点击 **Table Editor**
3. 查看 `topics`、`messages`、`reactions` 表
4. 应该能看到刚才创建的数据

---

## 🔧 常见问题

### Q: 部署后显示 404

**解决方法**：
- Vercel: 检查 `vercel.json` 是否存在
- Netlify: 检查 `netlify.toml` 是否存在

### Q: 部署后仍显示"Figma 预览模式"

**原因**：代码检测到 `figma` 关键词

**解决方法**：检查域名，不应该包含 "figma"

### Q: 数据库连接失败

**解决方法**：
1. 确认已运行 `SETUP_DATABASE.sql`
2. 检查 Supabase 项目未暂停（免费版闲置会暂停）
3. 在 Supabase Dashboard 中手动唤醒项目

### Q: 如何更新应用？

**简单方法**：
```bash
# 修改代码后
git add .
git commit -m "更新说明"
git push

# Vercel/Netlify 会自动重新部署
```

---

## 🎨 自定义域名

### Vercel 设置自定义域名

1. 在 Vercel 项目中，点击 **Settings**
2. 点击 **Domains**
3. 输入你的域名（例如：`ask.yourdomain.com`）
4. 按照提示在域名注册商处添加 DNS 记录
5. 等待 DNS 生效（通常几分钟）
6. ✅ 完成！

### 推荐域名注册商

- Namecheap
- Cloudflare
- GoDaddy
- 阿里云（国内）
- 腾讯云（国内）

---

## 📊 监控和分析

### 添加 Google Analytics（可选）

在 `index.html` 的 `<head>` 中添加：

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

---

## 🎉 恭喜！

你的 Ask Me Anything 应用已经成功部署到生产环境！

**接下来可以做的事：**
- 📱 分享给朋友使用
- 🎨 根据需求自定义样式
- 🔒 添加内容审核功能
- 📊 添加数据统计
- 🌍 添加多语言支持

需要帮助？随时联系！🚀
